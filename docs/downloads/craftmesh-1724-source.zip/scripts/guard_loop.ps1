# Persistent demo guard loop. Start with WMI Win32_Process.Create so it survives the caller.
# ASCII only: Windows PowerShell 5.1 reads .ps1 as ANSI unless BOM.
$ErrorActionPreference = 'Continue'
$Root      = 'C:\Users\xibei\Documents\deepseek-harness\default-workspace\clawhunt\1724-demo'
$PythonExe = 'C:\Users\xibei\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
$SshExe    = 'C:\Users\xibei\AppData\Local\GitHubDesktop\app-3.6.7\resources\app\git\usr\bin\ssh.exe'
$KeyPath   = 'C:\Users\xibei\Documents\deepseek-harness\default-workspace\.scratch\lhr_rsa'
$TokenFile = 'C:\Users\xibei\.config\craftmesh\gh_token'
$LogFile   = Join-Path $Root 'data\guard-loop.log'
$BaseUrl   = 'http://127.0.0.1:8787'

function Write-Log([string]$Message) {
    $line = '[' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz') + '] ' + $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}
function Get-Procs([string]$Pattern) {
    try {
        return @(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
            $_.CommandLine -and ($_.CommandLine -match $Pattern)
        })
    } catch { return @() }
}
function Test-Health {
    try {
        $r = Invoke-WebRequest -Uri ($BaseUrl + '/api/health') -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        return ($r.StatusCode -eq 200)
    } catch { return $false }
}
function Start-Server {
    Write-Log 'starting server.py'
    Start-Process -FilePath $PythonExe -ArgumentList @('server.py','--host','127.0.0.1','--port','8787') -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}
function Start-Tunnel {
    Write-Log 'starting tunnel watchdog'
    $targs = @(
        '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden',
        '-File', (Join-Path $Root 'scripts\keep_public_tunnel.ps1'),
        '-KeyPath',$KeyPath,
        '-RemoteUser','craftmesh5u60w8j6@fldubai.com@localhost.run',
        '-LocalPort','8787',
        '-SshExe',$SshExe,
        '-PythonExe',$PythonExe,
        '-TokenFile',$TokenFile
    )
    Start-Process -FilePath 'powershell.exe' -ArgumentList $targs -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

# Single instance, excluding this process.
$selfPid = $PID
$others = Get-Procs 'guard_loop\.ps1' | Where-Object { $_.ProcessId -ne $selfPid }
if ($others.Count -gt 0) { Write-Log ('another guard_loop running pid=' + (($others | ForEach-Object { $_.ProcessId }) -join ',')); exit 0 }
Write-Log 'guard_loop start'

$missingSsh = 0
$lastHealthLog = [DateTime]::MinValue
while ($true) {
    $server = Get-Procs 'server\.py.*--port\s+8787'
    if ($server.Count -eq 0) { Start-Server; Start-Sleep -Seconds 2 }
    if (-not (Test-Health)) {
        $server2 = Get-Procs 'server\.py.*--port\s+8787'
        if ($server2.Count -eq 0) { Start-Server; Start-Sleep -Seconds 2 }
    }

    $tunnel = Get-Procs 'keep_public_tunnel\.ps1'
    if ($tunnel.Count -eq 0) { Start-Tunnel; Start-Sleep -Seconds 2 }

    $ssh = Get-Procs 'ssh\.exe.*-R\s+80:127\.0\.0\.1:8787'
    if ($ssh.Count -eq 0) {
        $missingSsh++
        Write-Log ('ssh tunnel missing count=' + $missingSsh)
        if ($missingSsh -ge 3) {
            $old = Get-Procs 'keep_public_tunnel\.ps1'
            foreach ($proc in $old) { try { Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop; Write-Log ('killed stale watchdog pid=' + $proc.ProcessId) } catch {} }
            Start-Tunnel
            $missingSsh = 0
            Start-Sleep -Seconds 3
        }
    } else { $missingSsh = 0 }

    if (((Get-Date) - $lastHealthLog).TotalMinutes -ge 10) {
        $lastHealthLog = Get-Date
        if (Test-Health) { Write-Log 'health OK' } else { Write-Log 'health NOT OK' }
    }
    Start-Sleep -Seconds 30
}
