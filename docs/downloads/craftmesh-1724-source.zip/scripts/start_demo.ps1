param(
  [string]$PythonExe = "C:/Users/xibei/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe",
  [int]$Port = 8787,
  [string]$KeyPath = "C:/Users/xibei/Documents/deepseek-harness/default-workspace/.scratch/lhr_rsa",
  [string]$RemoteUser = "craftmesh5u60w8j6@fldubai.com@localhost.run",
  [string]$SshExe = "C:/Users/xibei/AppData/Local/GitHubDesktop/app-3.6.7/resources/app/git/usr/bin/ssh.exe",
  [string]$TokenFile = "C:/Users/xibei/.config/craftmesh/gh_token",
  [string]$LogPath = ""
)

# Supervisor: keep the local CraftMesh server and the localhost.run tunnel alive.
# Also asks Windows to stay awake (ES_CONTINUOUS | ES_SYSTEM_REQUIRED).
$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
if (-not $LogPath) { $LogPath = Join-Path $Root "data\demo-supervisor.log" }
$LogDir = Split-Path -Parent $LogPath
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }
$TunnelScript = Join-Path $PSScriptRoot "keep_public_tunnel.ps1"

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class KeepAwake {
  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern uint SetThreadExecutionState(uint esFlags);
  public static uint StayOn() { return SetThreadExecutionState(0x80000001u); }
}
"@

function Write-Log([string]$Text) {
  $line = "[" + (Get-Date -Format "yyyy-MM-ddTHH:mm:ssK") + "] " + $Text
  Add-Content -Path $LogPath -Value $line -Encoding UTF8
}

Write-Log "supervisor start port=$Port python=$PythonExe"
$tunnel = $null
while ($true) {
  [void][KeepAwake]::StayOn()
  $healthy = $false
  try {
    $resp = Invoke-WebRequest -UseBasicParsing -Uri ("http://127.0.0.1:" + $Port + "/api/health") -TimeoutSec 5
    if ($resp.StatusCode -eq 200) { $healthy = $true }
  } catch { }
  if (-not $healthy) {
    Write-Log "server health check failed; starting server"
    try {
      Start-Process -FilePath $PythonExe -ArgumentList @("server.py", "--host", "127.0.0.1", "--port", [string]$Port) -WorkingDirectory $Root -WindowStyle Hidden
    } catch { Write-Log ("server start error: " + $_.Exception.Message) }
    Start-Sleep -Seconds 3
  }
  if ($null -eq $tunnel -or $tunnel.HasExited) {
    Write-Log "starting tunnel watchdog"
    try {
      $tunnelArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", $TunnelScript, "-KeyPath", $KeyPath, "-RemoteUser", $RemoteUser, "-LocalPort", [string]$Port, "-SshExe", $SshExe, "-PythonExe", $PythonExe, "-TokenFile", $TokenFile)
      $tunnel = Start-Process -FilePath "C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe" -ArgumentList $tunnelArgs -PassThru -WindowStyle Hidden
      Write-Log ("tunnel watchdog pid=" + $tunnel.Id)
    } catch { Write-Log ("tunnel start error: " + $_.Exception.Message) }
  }
  Start-Sleep -Seconds 15
}
